sudo apt-get install python2 -y
sudo apt-get install python3 -y
sudo apt-get install python-pip
sudo apt-get install curl -y
sudo apt-get install termux-api -y
pip2 install mime
pip2 install colorama
pip2 install requests
pip2 install bs4

